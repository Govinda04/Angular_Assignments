import { Component } from '@angular/core';

@Component({
    selector: 'app-user',
    templateUrl: 'user.component.html'
})

export class UserComponent {
    uName: string;
    uMail: string;
    uPhone: number;
    flag = false;
    setFlag(): void{
        this.flag = true;
    }

    getUser(User): void{
        this.uName = User.name;
        this.uMail = User.mail;
        this.uPhone = User.phone;

        console.log(this.uName + '\n' + this.uMail + '\n' + this.uPhone)

    }
}
