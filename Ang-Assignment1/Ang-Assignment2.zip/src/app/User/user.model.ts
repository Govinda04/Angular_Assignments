export class User {
    constructor(
      public name: string,
      public mail: string,
      public phone: number) { }
  }
