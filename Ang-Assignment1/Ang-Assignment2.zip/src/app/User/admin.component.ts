import { Component , Output, EventEmitter} from '@angular/core';
import { User } from './user.model';

@Component({
    selector: 'app-admin',
    templateUrl: './admin.component.html'
})

export class AdminComponent {
    UserName: string;
    UserMail: string;
    UserPhone: number;
    hero: User;

    @Output() UserOut: EventEmitter<any> = new EventEmitter<any>();

    addUser(): void {
        this.hero = new User(this.UserName, this.UserMail, this.UserPhone);
        this.UserOut.emit(this.hero);
        console.log(this.hero);
        console.log(this.UserName);
        console.log('its working fine');
    }

}