export class User {
    static mail: any;
    constructor(
      public name: string,
      public mail: string,
      public phone: number) { }
  }
